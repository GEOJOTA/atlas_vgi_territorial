# Guía Técnica: Uso de Extractos Geofabrik en el Atlas VGI UAH

## 1. ¿Qué es Geofabrik?
Geofabrik es el principal proveedor de extractos regionales depurados de OpenStreetMap a nivel mundial. Cada noche procesa el planet dump de OSM y genera archivos recortados por países y continentes sin costo de acceso.

## 2. Enlaces de Descarga Directa Oficial
- **OSM PBF Chile (Recomendado):** [chile-latest.osm.pbf](https://download.geofabrik.de/south-america/chile-latest.osm.pbf)
- **Shapefiles Chile (ZIP):** [chile-latest-free.shp.zip](https://download.geofabrik.de/south-america/chile-latest-free.shp.zip)
- **Metadatos y Servidor Geofabrik:** https://download.geofabrik.de/south-america/chile.html

## 3. Apertura en QGIS
1. Descargue el archivo `.shp.zip` de Geofabrik y descomprímalo.
2. En QGIS, abra el menú `Capa` → `Añadir Capa` → `Añadir Capa Vectorial`.
3. Seleccione las capas de interés (ej. `gis_osm_buildings_a_free_1.shp` para edificaciones o `gis_osm_roads_free_1.shp` para vialidad).
4. Aplique un filtro espacial mediante la delimitación de Barrio Brasil contenida en `01_vgi_comunitario_osm/atlas_vgi_barrio_brasil_uah_completo.geojson`.

## 4. Filtrado con Osmium Tool (CLI)
Para recortar el archivo `.osm.pbf` al BBox exacto de Barrio Brasil:
```bash
osmium extract -b -70.6720,-33.4505,-70.6580,-33.4350 chile-latest.osm.pbf -o barrio_brasil_geofabrik.osm.pbf
```